#!/bin/bash
CHECK_FILE=/tmp/.start-semc-work
eth_interface=`ifconfig | grep '^eth' | awk '{print $1}'`

if [ -e $CHECK_FILE ]
then
	sudo mv /etc/resolv.conf-bak /etc/resolv.conf
	sudo route del -net 10.0.0.0 gw 192.168.11.181 netmask 255.0.0.0
    sudo route del -net 192.168.0.0/16 $eth_interface
	sudo rm $CHECK_FILE
fi

