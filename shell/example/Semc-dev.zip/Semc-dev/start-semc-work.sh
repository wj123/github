#!/bin/bash

CHECK_FILE=/tmp/.start-semc-work
eth_interface=`ifconfig | grep '^eth' | awk '{print $1}'`

if [ ! -e $CHECK_FILE ]
then
	sudo mv /etc/resolv.conf /etc/resolv.conf-bak

	sudo touch /etc/resolv.conf
	sudo chmod 777 /etc/resolv.conf
	sudo echo nameserver 10.158.0.3 > /etc/resolv.conf
    sudo echo nameserver 10.153.140.39 >> /etc/resolv.conf
	sudo cat  /etc/resolv.conf-bak >> /etc/resolv.conf

	sudo route add -net 192.168.0.0/16 $eth_interface
	sudo route add -net 10.0.0.0/8 gw 192.168.11.181
	touch $CHECK_FILE
    VPN=`ping -c 1 10.154.209.1 | grep '^64' | awk '{print $1}'`
    if [ -z $VPN ];then
        echo '代理没有连接成功！请确认route -n的结果是否有如下行："'
        echo "10.0.0.0  192.168.11.181   255.0.0.0  UG  0  0  0 $eth_interface"
        echo '如果没有，请尝试先执行stop-semc-work.sh，然后再执行start-semc-work.sh'
        echo '如果有，请向管理员确认代理服务器VPN是否可用。'
    else
        echo '恭喜！代理连接成功，为了确保VPN可用，请登录Sony任一网址如Gerrit(http://review.sonyericsson.net)。'
        echo '如果不能登录Gerrit，请联系管理员。'
    fi
fi



