#!/bin/bash

cd source/.build-script
source  ./com-config.sh
cd -

if [ ! -e $CHECK_MOUNT_FILE ]
then
	mkdir -p ./ftp-server
	sudo smbmount //192.168.11.30/ftp-public    ./ftp-server -o username=android-bt,password=android-bt123,uid=`id -u`,gid=`id -g`,ro

	echo Prepare local-repo
	if [ ! -e /usr/bin/smbmount ]
	then
	    sudo apt-get install samba
	    sudo apt-get install smbfs
	fi

	if [ ! -e $CHECK_SERVER_FILE ]
	then
#       sudo mkdir -p ./build-server
#       sudo smbmount //$ENV_SHARE_SERVER/semcj ./build-server -o use=share,pass=share,ro,uid=`id -u`,gid=`id -g`

		sudo mkdir -p $local_repo_mount_dir
		sudo smbmount //$ENV_SHARE_SERVER/local-repo $local_repo_mount_dir -o use=share,pass=share,ro,uid=`id -u`,gid=`id -g`
	fi

	touch $CHECK_MOUNT_FILE
fi


