#!/bin/bash

CHECK_FILE=$HOME/.gpg_public_key_added
SEMC_HOME=`pwd`

# The tools can be got from : http://swerepo.sonyericsson.net/pool/semc/
mountstatus=`mount | grep ftp-server` 
if [ -z "$mountstatus" ];then
   sudo smbmount //192.168.11.30/ftp-public  ./ftp-server -o username=android-bt,password=android-bt123,uid=1000,gid=1000
fi

VPN=`ping -c 1 10.154.209.1 | grep '^64' | awk '{print $1}'`
if [ -z "$VPN" ];then
    echo '检测到VPN（或者代理）不可用。安装(更新)sony编译工具包，必须要通过vpn（代理）。'
    echo '请确保VPN（代理）已正确连接并可用！'
else
    echo '检测到您已连接了VPN（或者代理）。'
    echo '请确认VPN（或者代理）可用。并且可以登录Sony地址如Gerrit（http://review.sonyericsson.net）。'
    echo '否则可能会导致安装失败!'
fi
read -p "如果确定，请按任意键继续" var


#Add sony software source to sources.list
sudo cp  /etc/apt/sources.list /etc/apt/sources.list.backup-`date +%Y%m%d`

sony_source1=`cat /etc/apt/sources.list | grep 'http://swerepo.sonyericsson.net stable semc'`
sony_source2=`cat /etc/apt/sources.list | grep 'http://mibtools.sonyericsson.net/repo lucid main'`
sony_source3=`cat /etc/apt/sources.list | grep 'http://linuxmirror-seld.sonyericsson.net/hp/Ubuntu lucid/current non-free'`

if [ -z "$sony_source1" ];then
    sudo add-apt-repository "deb http://swerepo.sonyericsson.net stable semc"
elif [ -z "$sony_source2" ];then
    sudo add-apt-repository "deb http://mibtools.sonyericsson.net/repo lucid main"
elif [ -z "$sony_source3" ];then
    sudo add-apt-repository "deb http://linuxmirror-seld.sonyericsson.net/hp/Ubuntu lucid/current non-free"
else
    echo "You have add all of sony source."
fi
#Add gpg public key
if [ ! -e $CHECK_FILE ];then
    if [ -d "$SEMC_HOME/ftp-server/SEMC/Other/gpg_public_key" ];then
        original_pwd=`pwd`
        cd ./ftp-server/SEMC/Other/gpg_public_key
        sudo apt-key add mibtools.gpg
        sudo apt-key add hewlett-packard.gpg
        sudo apt-key add swerepo.gpg
        touch $CHECK_FILE
        cd $original_pwd
    else
        echo
        echo "Maybe you have not mounted ftp-server, please make sure it's mounted"
        read -p "Press any key to continue." var
    fi
fi

sudo apt-get update

#Begin to install semc tools
sudo apt-get install -y modules
sudo apt-get install -y semc-cm-standard-tools
sudo apt-get install -y semc-eclipse-beta
sudo apt-get install -y semc-eclipse
sudo apt-get install -y prevent-package
sudo apt-get install -y semc-fakechroot
sudo apt-get install -y ant-contrib

sudo apt-get install -y semc-devenv-adb
sudo apt-get install -y semc-build


sudo apt-get install -y semc-libstdc++6
sudo apt-get install -y semc-apt
sudo apt-get install -y semc-apt0.8-lib
sudo apt-get install -y semc-apt0.8
sudo apt-get install -y c2d-solver

sudo apt-get install -y semcsc

sudo apt-get install -y signatory

sudo apt-get install -y semc-c2d
sudo apt-get install -y semc-sbuild
sudo apt-get install -y update-prevent-package-license
sudo apt-get install -y semc-crash
sudo apt-get install -y semc-devenv-devicehandling
sudo apt-get install -y semc-devenv-jobscript
sudo apt-get install -y semc-flashplugin
sudo apt-get install -y lzop

#Install debuggy in orde to convert crashlog to pdf format
sudo apt-get install -y debuggy

#Install buildcache for more quick compile.
sudo apt-get install -y buildcache
