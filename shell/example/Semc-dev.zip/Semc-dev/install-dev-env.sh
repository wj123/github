#!/bin/bash

SEMC_HOME=`pwd`

echo "Currect path is:" $SEMC_HOME
echo 
if [ -f $SEMC_HOME/update-semc-dev-packages.sh -a -f $SEMC_HOME/install-dev-env.sh ];then

    CHEK_INSTALL_FILE=$HOME/.semc-build-env-ok

    if [ -e $CHEK_INSTALL_FILE ];then
        echo "Maybe you have done installation before."
        echo
        while [ 1 ]
        do
           echo -n "Would you like to reinstall? (y/n)"
           read check
           case $check in
           y|Y)
               rm $CHEK_INSTALL_FILE
               break
               ;;
           n|N)
               exit 0
               ;;
           *)
               echo "Input ERROR, please try again."
               ;;
           esac
        done
     fi

######## Install the needed software
     echo '安装前请先将 系统->系统管理->软件源->其他软件->把勾都打上'
     read -p "Press any key to continue." var

     source1=`cat /etc/apt/sources.list | grep 'deb http://archive.canonical.com/ lucid partner'`
     source2=`cat /etc/apt/sources.list | grep 'deb http://archive.canonical.com/ubuntu lucid partner'`
     source3=`cat /etc/apt/sources.list | grep 'deb http://cn.archive.ubuntu.com/ubuntu/ lucid-backports main restricted universe multiverse'`
     source4=`cat /etc/apt/sources.list | grep 'deb-src http://cn.archive.ubuntu.com/ubuntu/ lucid-backports main restricted universe multiverse'`

     if [ -z "$source1" ];then
         sudo add-apt-repository 'deb http://archive.canonical.com/ lucid partner'
     elif [ -z "$source2" ];then
           sudo add-apt-repository 'deb http://archive.canonical.com/ubuntu lucid partner'
     elif [ -z "$source3" ];then
           sudo add-apt-repository 'deb http://cn.archive.ubuntu.com/ubuntu/ lucid-backports main restricted universe multiverse'
     elif [ -z "$source4" ];then
           sudo add-apt-repository 'deb-src http://cn.archive.ubuntu.com/ubuntu/ lucid-backports main restricted universe multiverse'
     else 
          echo "You have already added all of source."
     fi
     
     sudo add-apt-repository ppa:ferramroberto/java
     sudo apt-get update
     sudo apt-get upgrade

     sudo apt-get install -y ant lib32readline5-dev ant-optional lib32z1 bison lib32z1-dev build-essential libc6-dev-i386
     sudo apt-get install -y ca-certificates-java libesd0-dev  libcurl3 curl libmotif3 flex libncurses5-dev fusesmb libreadline5-dev
     sudo apt-get install -y g++-4.3-multilib libsasl2-modules-gssapi-mit g++-multilib libsdl1.2-dev gcc-4.3-multilib libx11-dev
     sudo apt-get install -y gcc-multilib meld git git-core menu git-gui sun-java6-jdk gitk tsocks gnuit valgrind gnupg
     sudo apt-get install -y vim gperf x11proto-core-dev ia32-libs zip lib32ncurses5-dev zlib1g-dev
     sudo apt-get install -y python-debian

     #sudo apt-get update
     #sudo apt-get upgrade

     echo Basic Software is finished

#### Semc build tool
     sudo apt-get install -y samba smbfs smbclient

     if [ ! -d $SEMC_HOME/ftp-server ];then
         mkdir $SEMC_HOME/ftp-server
     fi

     if [ -z "`mount | grep ftp-server`" ];then
         sudo smbmount //192.168.11.30/ftp-public    ./ftp-server -o username=android-bt,password=android-bt123,uid=1000,gid=1000
     fi

     cd $SEMC_HOME/ftp-server/SEMC/BuildEnv/semc-compile-tools

     sudo apt-get install -y reprepro
     sudo apt-get install -y eatmydata
     sudo apt-get install -y tcl8.4 tcl8.4-dev tclx8.4
     sudo apt-get install -y ant-contrib

     /bin/sh $SEMC_HOME/update-semc-dev-packages.sh

     sudo cp /etc/opt/cert_data.dat /etc/opt/cert_data-bak-for-semc.data
     sudo cp $SEMC_HOME/ftp-server/SEMC/BuildEnv/cert_data.dat /etc/opt/cert_data.dat

#sudo umount ./ftp-server
     if [ $? = 0 ];then
         touch $CHEK_INSTALL_FILE
         echo "======================================"
         echo Semc build tools are installed finished
         echo "======================================"
         exit 0
     else
         echo "================================================================="
         echo "Semc build tools are NOT installed successfully.Please check log."
         echo "================================================================="
         exit 1
     fi

else
     echo "ERROR:"
     echo "Maybe you are NOT at correct path, please switch into where your 'semc-dev' located."
     exit 1
fi 
     
